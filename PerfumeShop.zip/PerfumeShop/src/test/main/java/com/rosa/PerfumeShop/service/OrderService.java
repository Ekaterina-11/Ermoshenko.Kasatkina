package com.rosa.PerfumeShop.service;

import com.rosa.PerfumeShop.domain.Order;
import com.rosa.PerfumeShop.domain.User;

import java.util.List;

public interface OrderService {
    List<Order> findAll();
    Order save(Order order);
    List<Order> findOrderByUser(User user);
}
